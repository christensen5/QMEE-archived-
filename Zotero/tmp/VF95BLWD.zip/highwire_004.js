(function ($) {
  $.fn.highwireEqualHeights = function() {
    if (Drupal.behaviors.hasOwnProperty('omegaEqualHeights')) {
      $(window).trigger('resize.omegaequalheights');
    }
  };
})(jQuery);
