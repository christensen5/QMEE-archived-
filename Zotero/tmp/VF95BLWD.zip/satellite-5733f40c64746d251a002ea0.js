if( typeof _sdi == 'undefined' ) { _sdi = {} }
