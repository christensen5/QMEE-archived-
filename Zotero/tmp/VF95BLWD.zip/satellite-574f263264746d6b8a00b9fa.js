_satellite.pushAsyncScript(function(event, target, $variables){
  _satellite.setCookie('is_aaas_user','y',180);
});
