_satellite.pushAsyncScript(function(event, target, $variables){
  jQuery('a[href="#login-pane"]').click(function(){
  if( jQuery('#login-pane.is-visually-hidden').length == 0 ) { // login pane is currently hidden, so the click displays the paywall
    _satellite.track('paywallPane');
  }
});
});
