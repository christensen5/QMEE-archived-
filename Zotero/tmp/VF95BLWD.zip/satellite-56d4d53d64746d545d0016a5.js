function uptUrl() {
  document.getElementById('__successPage').value=document.getElementById('__successPage').value+'&firstname='+document.getElementById('firstname').value+'&lastname='+document.getElementById('lastname').value+'&email='+document.getElementById('email').value;
}
