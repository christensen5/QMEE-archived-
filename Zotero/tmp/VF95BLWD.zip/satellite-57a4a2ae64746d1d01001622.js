_satellite.pushAsyncScript(function(event, target, $variables){
  _satellite.setCookie('ist_usr','y',180);
});
